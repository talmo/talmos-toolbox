function mX = eztsne(X)
%EZTSNE Manifold embedding -- quick and easy!
% Usage:
%   eztsne(X)
%   mX = eztsne(X)
%
% See also: tsne, tsne_pca

% Params
labels = ones(size(X,1),1);
no_dims = 2; % target dimensions
initial_dims = 0.99;
perplexity = 5;
max_iter = 500;

% Go!
mX = tsne(X, labels, no_dims, initial_dims, perplexity, max_iter);

% Visualize
figure
scatter(mX(:,1), mX(:,2), 5, 'filled')
title(sprintf('t-SNE Embedding (n = %d)', size(mX,1)))

if nargout < 1
    clear mX
end

end

